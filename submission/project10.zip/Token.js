Object.defineProperty(exports, "__esModule", { value: true });
class Token {
    constructor(type, value) {
        this.type = type;
        this.value = value;
    }
}
exports.default = Token;
