Object.defineProperty(exports, "__esModule", { value: true });
class VarAttr {
    constructor(type, kind, index) {
        this.type = type;
        this.kind = kind;
        this.index = index;
    }
}
exports.default = VarAttr;
